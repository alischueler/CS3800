public class Terminal{
    String terminal;

    public Terminal(String s) {
        this.terminal = s;
    }
    public Terminal() {

    }

    @Override
    public String toString() {
        return terminal;
    }
}
