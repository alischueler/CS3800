# CFG Data Representation:
A Variable is a String
A Terminal is a String
A Rule is a String, LinkedHashSet of String
A context-free grammar is a 4-tuple (Variables, Terminals, Rules, Start), where
1. Variables are a LinkedHashSet of String
2. Terminals are a LinkedHashSet ot String
3. Rules are a Map of String, LinkedHashSet of String
4. Start Variable is a Variable

Time spent:
10 hours

Sites Used:
office hours help!\
https://www.geeksforgeeks.org/print-all-permutations-of-a-string-in-java/